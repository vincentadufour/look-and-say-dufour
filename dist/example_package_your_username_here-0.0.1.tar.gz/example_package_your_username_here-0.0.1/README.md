# look-and-say-dufour
Python Package for a Look-And-Say sequence iterator

## This Look-And-Say-Dufour package prints a string of the look-and-say sequence up to the iterator amount passed.